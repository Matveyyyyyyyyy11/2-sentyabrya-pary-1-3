"""Unit tests for the HTTP serializer."""

from src.http.parser import Parser
from src.http.request import Request
from src.http.response import Response
from src.http.serializer import Serializer


def test_serialize_request_ends_with_blank_line():
    raw = Serializer.serialize_request(Request("GET", "/"))
    assert raw.endswith(b"\r\n\r\n")


def test_serialize_request_contains_start_line():
    raw = Serializer.serialize_request(
        Request("GET", "/index?x=1", headers={"Host": "h"}))
    assert raw.startswith(b"GET /index?x=1 HTTP/1.1\r\n")


def test_serialize_request_body_length():
    raw = Serializer.serialize_request(Request("POST", "/echo", body=b"abc"))
    assert b"Content-Length: 3\r\n" in raw
    assert raw.endswith(b"\r\n\r\nabc")


def test_serialize_response_has_content_length():
    raw = Serializer.serialize_response(Response(200, body=b"hello"))
    assert b"Content-Length: 5\r\n" in raw
    assert raw.endswith(b"\r\n\r\nhello")


def test_response_without_reason_has_valid_status_line():
    raw = Serializer.serialize_response(Response(599, body=b""))
    assert raw.startswith(b"HTTP/1.1 599\r\n")


def test_request_round_trip():
    original = Request(
        "POST", "/echo",
        headers={"Host": "localhost", "Content-Type": "text/plain"},
        body=b"abc",
    )
    parsed = Parser.parse_request(Serializer.serialize_request(original))
    assert parsed.method == original.method
    assert parsed.path == original.path
    assert parsed.body == original.body


def test_response_round_trip():
    original = Response(
        200, reason="OK", headers={"Content-Type": "text/plain"}, body=b"hello")
    parsed = Parser.parse_response(Serializer.serialize_response(original))
    assert parsed.status == 200
    assert parsed.body == b"hello"
    assert parsed.get_header("content-type") == "text/plain"
