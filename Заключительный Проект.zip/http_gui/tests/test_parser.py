"""Unit tests for the HTTP parser (U4-U10 and edge cases)."""

import pytest

from src.http.parser import MAX_HEADER_SIZE, Parser
from src.http.url import ParseError


def test_parse_simple_request():
    request = Parser.parse_request(b"GET / HTTP/1.1\r\nHost: localhost\r\n\r\n")
    assert request.method == "GET"
    assert request.path == "/"
    assert request.version == "HTTP/1.1"
    assert request.get_header("host") == "localhost"


def test_parse_request_with_body():
    raw = b"POST /echo HTTP/1.1\r\nHost: localhost\r\nContent-Length: 3\r\n\r\nabc"
    request = Parser.parse_request(raw)
    assert request.body == b"abc"


def test_parse_request_without_host():
    with pytest.raises(ParseError):
        Parser.parse_request(b"GET / HTTP/1.1\r\n\r\n")


def test_parse_request_without_body():
    request = Parser.parse_request(b"GET /time HTTP/1.1\r\nHost: x\r\n\r\n")
    assert request.body == b""


def test_parse_request_invalid_start_line():
    with pytest.raises(ParseError):
        Parser.parse_request(b"GET /\r\nHost: x\r\n\r\n")


def test_parse_request_invalid_header():
    with pytest.raises(ParseError):
        Parser.parse_request(b"GET / HTTP/1.1\r\nHost: x\r\nBadHeader\r\n\r\n")


def test_parse_request_incomplete_body():
    raw = b"POST / HTTP/1.1\r\nHost: x\r\nContent-Length: 10\r\n\r\nabc"
    with pytest.raises(ParseError):
        Parser.parse_request(raw)


def test_parse_response():
    response = Parser.parse_response(
        b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nhi")
    assert response.status == 200
    assert response.reason == "OK"
    assert response.body == b"hi"


def test_parse_chunked_response():
    raw = (
        b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n"
        b"4\r\nWiki\r\n5\r\npedia\r\n0\r\n\r\n"
    )
    response = Parser.parse_response(raw)
    assert response.body == b"Wikipedia"


def test_parse_response_without_length_reads_all():
    response = Parser.parse_response(b"HTTP/1.1 200 OK\r\n\r\nhello")
    assert response.body == b"hello"


def test_large_header_is_rejected():
    raw = (
        b"GET / HTTP/1.1\r\nHost: x\r\nX-Big: "
        + b"a" * MAX_HEADER_SIZE
        + b"\r\n\r\n"
    )
    with pytest.raises(ParseError):
        Parser.parse_request(raw)


def test_malformed_chunk_is_rejected():
    raw = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\nZZ\r\n"
    with pytest.raises(ParseError):
        Parser.parse_response(raw)


def test_header_names_are_case_insensitive():
    request = Parser.parse_request(
        b"GET / HTTP/1.1\r\nhost: localhost\r\nx-test: yes\r\n\r\n")
    assert request.get_header("Host") == "localhost"
    assert request.get_header("X-Test") == "yes"
