"""Load test: 100 parallel requests against a real server (S12)."""

import threading
import time
from concurrent.futures import ThreadPoolExecutor

import pytest

from src.client.http_client import HttpClient
from src.server.handlers import create_router
from src.server.http_server import HttpServer

REQUESTS = 100


@pytest.fixture
def server():
    srv = HttpServer(port=0, router=create_router())
    srv.start()
    yield srv
    srv.stop()


def test_100_parallel_requests(server):
    url = f"http://127.0.0.1:{server.port}/time"
    barrier = threading.Barrier(REQUESTS)

    def worker(_index):
        client = HttpClient(timeout_ms=10000)
        barrier.wait(timeout=10)
        return client.get(url).status

    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=REQUESTS) as pool:
        statuses = list(pool.map(worker, range(REQUESTS)))
    elapsed = time.perf_counter() - started

    assert statuses == [200] * REQUESTS
    assert elapsed < 15
    print(f"\n{REQUESTS} parallel requests: all 200 in {elapsed:.2f}s")
