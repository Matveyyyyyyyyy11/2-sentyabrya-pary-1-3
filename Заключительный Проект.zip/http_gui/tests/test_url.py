"""Unit tests for Url.parse (U1-U3 and edge cases)."""

import pytest

from src.http.url import ParseError, Url


def test_parse_full_url():
    url = Url.parse("http://host:8080/path?q=1")
    assert url.scheme == "http"
    assert url.host == "host"
    assert url.port == 8080
    assert url.path == "/path"
    assert url.query == "q=1"


def test_default_port_http():
    assert Url.parse("http://host/path").port == 80


def test_default_port_https():
    assert Url.parse("https://example.com/").port == 443


def test_path_is_optional():
    url = Url.parse("http://host")
    assert url.path == "/"
    assert url.query == ""


def test_target_includes_query():
    assert Url.parse("http://host/a?b=c").target == "/a?b=c"


def test_host_header_with_custom_port():
    assert Url.parse("http://host:8080/").host_header == "host:8080"


def test_host_header_without_port():
    assert Url.parse("http://host/").host_header == "host"


def test_whitespace_is_trimmed():
    assert Url.parse("  http://host/  ").host == "host"


@pytest.mark.parametrize(
    "value",
    [
        "garbage",
        "",
        "ftp://host/",
        "http://",
        "http://host:0/",
        "http://host:70000/",
        "http://host:abc/",
        "http://host/#fragment",
    ],
)
def test_invalid_url(value):
    with pytest.raises(ParseError):
        Url.parse(value)
