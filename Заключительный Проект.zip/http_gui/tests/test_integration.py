"""Integration tests: real server in a thread and the socket client."""

import socket
import threading
import time

import pytest

from src.client.http_client import HttpClient, HttpError
from src.server.handlers import create_router
from src.server.http_server import HttpServer


@pytest.fixture
def server():
    srv = HttpServer(port=0, router=create_router())
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture
def client():
    return HttpClient(timeout_ms=3000)


def make_url(server, path):
    return f"http://127.0.0.1:{server.port}{path}"


def read_raw_response(sock):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = sock.recv(4096)
        assert chunk
        data += chunk
    head, body = data.split(b"\r\n\r\n", 1)
    length = 0
    for line in head.split(b"\r\n")[1:]:
        name, value = line.split(b":", 1)
        if name.strip().lower() == b"content-length":
            length = int(value.strip())
    while len(body) < length:
        chunk = sock.recv(4096)
        assert chunk
        body += chunk
    status = int(head.split(b" ")[1])
    return status, body


def test_get_root(server, client):
    response = client.get(make_url(server, "/"))
    assert response.status == 200
    assert b"Hello" in response.body


def test_post_echo(server, client):
    response = client.post(make_url(server, "/echo"), b"abc", "text/plain")
    assert response.status == 200
    assert response.body == b"abc"
    assert response.get_header("Content-Type") == "text/plain"


def test_time_returns_json(server, client):
    response = client.get(make_url(server, "/time"))
    assert response.status == 200
    assert b"time" in response.body


def test_headers_route(server, client):
    response = client.get(make_url(server, "/headers"), headers={"X-Test": "yes"})
    assert response.status == 200
    assert b"X-Test" in response.body


def test_status_404_raises_http_error(server, client):
    with pytest.raises(HttpError) as error:
        client.get(make_url(server, "/status/404"))
    assert error.value.status == 404
    assert error.value.response.status == 404


def test_status_418(server, client):
    with pytest.raises(HttpError) as error:
        client.get(make_url(server, "/status/418"))
    assert error.value.status == 418


def test_unknown_path_returns_404(server, client):
    with pytest.raises(HttpError) as error:
        client.get(make_url(server, "/nonexistent"))
    assert error.value.status == 404


def test_sequential_requests(server, client):
    for _ in range(50):
        assert client.get(make_url(server, "/")).status == 200


def test_parallel_requests(server):
    results = []
    lock = threading.Lock()

    def worker():
        local_client = HttpClient(timeout_ms=5000)
        status = local_client.get(make_url(server, "/")).status
        with lock:
            results.append(status)

    threads = [threading.Thread(target=worker) for _ in range(10)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert results == [200] * 10


def test_timeout():
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    port = listener.getsockname()[1]

    def slow_server():
        try:
            conn, _ = listener.accept()
            time.sleep(1)
            conn.close()
        except OSError:
            pass

    thread = threading.Thread(target=slow_server, daemon=True)
    thread.start()
    try:
        client = HttpClient(timeout_ms=100)
        with pytest.raises(TimeoutError):
            client.get(f"http://127.0.0.1:{port}/")
    finally:
        listener.close()
        thread.join(timeout=2)


def test_garbage_request_gets_400(server, client):
    with socket.create_connection(("127.0.0.1", server.port), timeout=2) as sock:
        sock.sendall(b"garbage\r\n\r\n")
        data = sock.recv(4096)
    assert data.startswith(b"HTTP/1.1 400")
    assert client.get(make_url(server, "/")).status == 200


def test_keep_alive_three_requests(server):
    with socket.create_connection(("127.0.0.1", server.port), timeout=2) as sock:
        for _ in range(3):
            sock.sendall(
                b"GET / HTTP/1.1\r\nHost: localhost\r\n"
                b"Connection: keep-alive\r\n\r\n"
            )
            status, body = read_raw_response(sock)
            assert status == 200
            assert b"Hello" in body


def test_many_requests(server, client):
    for _ in range(100):
        assert client.get(make_url(server, "/time")).status == 200


def test_query_string_is_ignored(server, client):
    response = client.get(make_url(server, "/time?x=1"))
    assert response.status == 200


def test_large_post_body(server, client):
    body = b"x" * 10000
    response = client.post(make_url(server, "/echo"), body, "application/octet-stream")
    assert response.status == 200
    assert response.body == body
