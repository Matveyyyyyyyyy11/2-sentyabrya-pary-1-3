"""High level HTTP client built on raw sockets."""

import logging
from abc import ABC, abstractmethod
from typing import Dict, Optional

from ..http.parser import MAX_BODY_SIZE, MAX_HEADER_SIZE, Parser
from ..http.request import Request, get_header
from ..http.response import Response
from ..http.serializer import Serializer
from ..http.url import ParseError, Url
from ..net.tcp_client import TcpClient

logger = logging.getLogger(__name__)


class HttpError(Exception):
    """Raised when the server responds with a 4xx/5xx status."""

    def __init__(self, status: int, response: Optional[Response] = None):
        self.status = status
        self.response = response
        super().__init__(f"HTTP error {status}")


class Client(ABC):
    """Common interface for an HTTP client."""

    @abstractmethod
    def get(self, url: str, headers: Optional[Dict[str, str]] = None) -> Response:
        """Send a GET request."""

    @abstractmethod
    def post(self, url: str, body, content_type: str = "text/plain",
             headers: Optional[Dict[str, str]] = None) -> Response:
        """Send a POST request."""

    @abstractmethod
    def set_timeout(self, ms: int) -> None:
        """Set connect/read timeout in milliseconds."""


class HttpClient(Client):
    """A small HTTP/1.1 client with redirects and TLS support."""

    def __init__(self, timeout_ms: int = 5000, follow_redirects_max: int = 0):
        self._timeout_ms = timeout_ms
        self._max_redirects = follow_redirects_max
        self.raise_for_status = True

    def set_timeout(self, ms: int) -> None:
        if ms <= 0:
            raise ValueError("Timeout must be positive")
        self._timeout_ms = int(ms)

    def follow_redirects(self, max_redirects: int) -> None:
        self._max_redirects = max(0, int(max_redirects))

    def get(self, url: str, headers: Optional[Dict[str, str]] = None) -> Response:
        return self.request("GET", url, headers=headers)

    def post(self, url: str, body, content_type: str = "text/plain",
             headers: Optional[Dict[str, str]] = None) -> Response:
        if isinstance(body, str):
            body = body.encode("utf-8")
        return self.request("POST", url, body=body, content_type=content_type, headers=headers)

    def request(self, method: str, url: str, body: bytes = b"",
                content_type: str = "text/plain",
                headers: Optional[Dict[str, str]] = None,
                redirects_left: Optional[int] = None) -> Response:
        if redirects_left is None:
            redirects_left = self._max_redirects
        target = Url.parse(url)
        request = self._build_request(target, method, body, content_type, headers)
        logger.info("%s %s", method, url)
        response = self._send(target, request)
        logger.info("%s %s -> %s", method, url, response.status)

        if response.status in (301, 302, 303, 307, 308) and redirects_left > 0:
            location = response.get_header("Location")
            if location:
                next_url = self._resolve(target, location)
                if response.status == 303 or (
                    response.status in (301, 302) and method == "POST"
                ):
                    return self.request("GET", next_url, headers=headers,
                                        redirects_left=redirects_left - 1)
                return self.request(method, next_url, body=body, content_type=content_type,
                                    headers=headers, redirects_left=redirects_left - 1)

        if self.raise_for_status and response.status >= 400:
            raise HttpError(response.status, response)
        return response

    def _build_request(self, target: Url, method: str, body: bytes, content_type: str,
                       headers: Optional[Dict[str, str]]) -> Request:
        result = dict(headers or {})
        if not any(name.lower() == "host" for name in result):
            result["Host"] = target.host_header
        result.setdefault("User-Agent", "http-gui/1.0")
        result.setdefault("Accept", "*/*")
        result.setdefault("Connection", "close")
        if method == "POST":
            result.setdefault("Content-Type", content_type)
        return Request(method=method, path=target.target, headers=result, body=body)

    def _send(self, target: Url, request: Request) -> Response:
        payload = Serializer.serialize_request(request)
        with TcpClient(self._timeout_ms / 1000) as tcp:
            tcp.connect(target.host, target.port, use_ssl=target.scheme == "https")
            tcp.send(payload)
            raw = self._read_response(tcp)
        return Parser.parse_response(raw)

    @staticmethod
    def _read_response(tcp: TcpClient) -> bytes:
        data = tcp.recv_until(b"\r\n\r\n", max_bytes=MAX_HEADER_SIZE + 4096)
        head, rest = data.split(b"\r\n\r\n", 1)
        start_line, headers = Parser.parse_head(head)
        status = HttpClient._status_from_line(start_line)

        if 100 <= status < 200 or status in (204, 304):
            return head + b"\r\n\r\n"

        encoding = get_header(headers, "Transfer-Encoding")
        if encoding and "chunked" in encoding.lower():
            while not rest.endswith(b"0\r\n\r\n"):
                chunk = tcp.recv(4096)
                if not chunk:
                    break
                rest += chunk
                if len(rest) > MAX_BODY_SIZE:
                    raise ParseError("Response body is too large")
            return head + b"\r\n\r\n" + rest

        length_text = get_header(headers, "Content-Length")
        if length_text is not None:
            try:
                length = int(length_text)
            except ValueError as exc:
                raise ParseError("Invalid Content-Length") from exc
            if length < 0 or length > MAX_BODY_SIZE:
                raise ParseError("Invalid Content-Length")
            while len(rest) < length:
                chunk = tcp.recv(4096)
                if not chunk:
                    raise ConnectionError("Connection closed before the body was read")
                rest += chunk
            return head + b"\r\n\r\n" + rest[:length]

        while True:
            chunk = tcp.recv(4096)
            if not chunk:
                break
            rest += chunk
            if len(rest) > MAX_BODY_SIZE:
                raise ParseError("Response body is too large")
        return head + b"\r\n\r\n" + rest

    @staticmethod
    def _status_from_line(start_line: str) -> int:
        parts = start_line.split(" ", 2)
        if len(parts) < 2:
            raise ParseError("Invalid status line")
        try:
            return int(parts[1])
        except ValueError as exc:
            raise ParseError("Invalid status code") from exc

    @staticmethod
    def _resolve(base: Url, location: str) -> str:
        if location.startswith("http://") or location.startswith("https://"):
            return location
        if not location.startswith("/"):
            directory = base.path.rsplit("/", 1)[0]
            location = f"{directory}/{location}"
        return f"{base.scheme}://{base.host_header}{location}"
