"""HTTP server built on top of TcpServer."""

import logging
import time
from typing import Callable, Optional

from ..http.parser import MAX_BODY_SIZE, MAX_HEADER_SIZE, Parser
from ..http.request import get_header
from ..http.response import make_response
from ..http.serializer import Serializer
from ..http.url import ParseError
from ..net.socket_wrapper import Socket
from ..net.tcp_server import Server, TcpServer
from .handlers import create_router
from .router import Router

logger = logging.getLogger(__name__)

BAD_REQUEST = make_response(400, "400 Bad Request")
LogCallback = Callable[[str, str, str, int, float], None]


class HttpServer(Server):
    """HTTP/1.1 server with one thread per connection."""

    def __init__(self, port: int = 8080, router: Optional[Router] = None,
                 on_log: Optional[LogCallback] = None, host: str = "127.0.0.1"):
        self._router = router if router is not None else create_router()
        self._on_log = on_log
        self._tcp = TcpServer(host, port, self._handle_connection)
        self.port = port

    @property
    def running(self) -> bool:
        return self._tcp.running

    def start(self) -> None:
        self._tcp.start()
        self.port = self._tcp.port
        logger.info("HTTP server started on http://127.0.0.1:%s/", self.port)

    def stop(self) -> None:
        self._tcp.stop()
        logger.info("HTTP server stopped")

    def _handle_connection(self, sock: Socket) -> None:
        sock.settimeout(5)
        while self._tcp.running:
            try:
                raw = self._read_request(sock)
            except ParseError as exc:
                logger.warning("Bad request: %s", exc)
                self._send(sock, BAD_REQUEST)
                self._log("-", "-", BAD_REQUEST.status, 0.0)
                return
            except OSError:
                return
            if raw is None:
                return

            started = time.perf_counter()
            try:
                request = Parser.parse_request(raw)
                response = self._router.dispatch(request)
            except ParseError as exc:
                logger.warning("Cannot parse request: %s", exc)
                self._send(sock, BAD_REQUEST)
                elapsed = (time.perf_counter() - started) * 1000
                self._log("-", "-", BAD_REQUEST.status, elapsed)
                return

            elapsed = (time.perf_counter() - started) * 1000
            self._send(sock, response)
            self._log(request.method, request.path, response.status, elapsed)

            connection = request.get_header("Connection") or ""
            if connection.lower() == "close" or request.version == "HTTP/1.0":
                return

    @staticmethod
    def _read_request(sock: Socket) -> Optional[bytes]:
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = sock.recv(4096)
            if not chunk:
                if not data:
                    return None
                raise ParseError("Incomplete request")
            data += chunk
            if b"\r\n\r\n" not in data and len(data) > MAX_HEADER_SIZE:
                raise ParseError("Headers are too large")

        head, rest = data.split(b"\r\n\r\n", 1)
        if len(head) > MAX_HEADER_SIZE:
            raise ParseError("Headers are too large")
        _, headers = Parser.parse_head(head)

        if get_header(headers, "Transfer-Encoding") is not None:
            raise ParseError("Chunked request bodies are not supported")

        length_text = get_header(headers, "Content-Length") or "0"
        try:
            length = int(length_text)
        except ValueError as exc:
            raise ParseError("Invalid Content-Length") from exc
        if length < 0 or length > MAX_BODY_SIZE:
            raise ParseError("Invalid Content-Length")

        while len(rest) < length:
            chunk = sock.recv(4096)
            if not chunk:
                raise ParseError("Incomplete request body")
            rest += chunk

        return head + b"\r\n\r\n" + rest[:length]

    @staticmethod
    def _send(sock: Socket, response) -> None:
        try:
            sock.send_all(Serializer.serialize_response(response))
        except OSError:
            pass

    def _log(self, method: str, path: str, status: int, ms: float) -> None:
        logger.info("%s %s -> %s (%.1f ms)", method, path, status, ms)
        if self._on_log is not None:
            self._on_log(time.strftime("%H:%M:%S"), method, path, status, ms)
