"""Request handlers for the demo server."""

import json
from datetime import datetime

from ..http.request import Request
from ..http.response import Response, make_response
from .router import Router

HELLO_PAGE = """<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Hello</title></head>
<body>
  <h1>Hello</h1>
  <p>This page is served by the Python socket HTTP server.</p>
  <ul>
    <li>GET /time</li>
    <li>GET /headers</li>
    <li>POST /echo</li>
    <li>GET /status/{code}</li>
  </ul>
</body>
</html>
"""


def hello(_request: Request) -> Response:
    return make_response(200, HELLO_PAGE, "text/html; charset=utf-8")


def echo(request: Request) -> Response:
    content_type = request.get_header("Content-Type") or "application/octet-stream"
    return make_response(200, request.body, content_type)


def current_time(_request: Request) -> Response:
    payload = json.dumps({"time": datetime.now().isoformat(timespec="seconds")})
    return make_response(200, payload, "application/json; charset=utf-8")


def request_headers(request: Request) -> Response:
    payload = json.dumps(request.headers, ensure_ascii=False, indent=2)
    return make_response(200, payload, "application/json; charset=utf-8")


def create_router() -> Router:
    router = Router()
    router.route("GET", "/", hello)
    router.route("POST", "/echo", echo)
    router.route("GET", "/time", current_time)
    router.route("GET", "/headers", request_headers)
    return router
