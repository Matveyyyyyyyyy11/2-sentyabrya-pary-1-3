"""Request router."""

import logging
from typing import Callable, Dict, Tuple

from ..http.request import Request
from ..http.response import Response, make_response

logger = logging.getLogger(__name__)

Handler = Callable[[Request], Response]


class Router:
    """Maps (method, path) pairs to handler callables."""

    def __init__(self):
        self._routes: Dict[Tuple[str, str], Handler] = {}

    def route(self, method: str, path: str, handler: Handler) -> None:
        self._routes[(method.upper(), path)] = handler

    def dispatch(self, request: Request) -> Response:
        path = request.path.split("?", 1)[0]
        handler = self._routes.get((request.method.upper(), path))
        if handler is not None:
            return handler(request)

        if path.startswith("/status/"):
            code_text = path[len("/status/"):]
            try:
                code = int(code_text)
            except ValueError:
                code = 0
            if 100 <= code <= 599:
                return make_response(code)

        return make_response(404, "404 Not Found")
