"""Serialization of Request/Response objects into raw HTTP bytes."""

from typing import Dict

from .request import Request
from .response import Response


class Serializer:
    """Turns Request and Response objects into bytes."""

    @staticmethod
    def serialize_request(request: Request) -> bytes:
        start_line = f"{request.method} {request.path} {request.version}"
        return Serializer._serialize(start_line, request.headers, request.body)

    @staticmethod
    def serialize_response(response: Response) -> bytes:
        start_line = f"{response.version} {response.status}"
        if response.reason:
            start_line += f" {response.reason}"
        return Serializer._serialize(start_line, response.headers, response.body)

    @staticmethod
    def _serialize(start_line: str, headers: Dict[str, str], body: bytes) -> bytes:
        items = {name: str(value) for name, value in headers.items()}
        for name in [key for key in items if key.lower() == "content-length"]:
            del items[name]
        items["Content-Length"] = str(len(body))

        lines = [start_line]
        lines.extend(f"{name}: {value}" for name, value in items.items())
        head = "\r\n".join(lines) + "\r\n\r\n"
        return head.encode("latin-1") + body
