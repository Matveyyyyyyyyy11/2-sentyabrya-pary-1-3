"""HTTP message models, parser and serializer."""
