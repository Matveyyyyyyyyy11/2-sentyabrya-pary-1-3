"""HTTP response model and a small response factory."""

from dataclasses import dataclass, field
from email.utils import formatdate
from http.client import responses
from typing import Dict, Optional

from .request import get_header


@dataclass
class Response:
    """An HTTP response."""

    status: int
    reason: str = ""
    version: str = "HTTP/1.1"
    headers: Dict[str, str] = field(default_factory=dict)
    body: bytes = b""

    def __post_init__(self) -> None:
        if not self.reason:
            self.reason = responses.get(self.status, "")

    def get_header(self, name: str) -> Optional[str]:
        return get_header(self.headers, name)


def make_response(status: int, body=b"", content_type="text/plain; charset=utf-8") -> Response:
    """Build a response with the headers required by the task."""
    if isinstance(body, str):
        body = body.encode("utf-8")
    headers = {
        "Content-Type": content_type,
        "Date": formatdate(usegmt=True),
    }
    return Response(status=status, headers=headers, body=body)
