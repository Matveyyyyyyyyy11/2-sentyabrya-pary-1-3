"""Parsing of raw HTTP requests and responses."""

from typing import Dict, List, Tuple

from .request import Request, get_header
from .response import Response
from .url import ParseError

MAX_HEADER_SIZE = 8 * 1024
MAX_BODY_SIZE = 1024 * 1024


class Parser:
    """Stateless HTTP/1.1 message parser."""

    @staticmethod
    def parse_head(head: bytes) -> Tuple[str, Dict[str, str]]:
        """Split a header block into the start line and a header dict."""
        if len(head) > MAX_HEADER_SIZE:
            raise ParseError("Headers are too large")
        lines = head.split(b"\r\n")
        if not lines or not lines[0].strip():
            raise ParseError("Empty start line")
        start_line = lines[0].decode("latin-1")
        headers = Parser._parse_headers(lines[1:])
        return start_line, headers

    @staticmethod
    def parse_request(data: bytes) -> Request:
        """Parse a complete raw HTTP request."""
        head, body = Parser._split(data)
        start_line, headers = Parser.parse_head(head)
        parts = start_line.split(" ")
        if len(parts) != 3:
            raise ParseError("Invalid request line")
        method, path, version = parts
        if not version.startswith("HTTP/"):
            raise ParseError("Invalid HTTP version")
        if not path.startswith("/"):
            raise ParseError("Invalid request path")
        if get_header(headers, "Host") is None:
            raise ParseError("Host header is required")
        return Request(
            method=method.upper(),
            path=path,
            version=version,
            headers=headers,
            body=Parser._read_body(headers, body),
        )

    @staticmethod
    def parse_response(data: bytes) -> Response:
        """Parse a complete raw HTTP response."""
        head, body = Parser._split(data)
        start_line, headers = Parser.parse_head(head)
        parts = start_line.split(" ", 2)
        if len(parts) < 2:
            raise ParseError("Invalid status line")
        version = parts[0]
        if not version.startswith("HTTP/"):
            raise ParseError("Invalid HTTP version")
        try:
            status = int(parts[1])
        except ValueError as exc:
            raise ParseError("Invalid status code") from exc
        reason = parts[2] if len(parts) > 2 else ""
        return Response(
            status=status,
            reason=reason,
            version=version,
            headers=headers,
            body=Parser._read_body(headers, body, default_all=True),
        )

    @staticmethod
    def _split(data: bytes) -> Tuple[bytes, bytes]:
        if not isinstance(data, bytes):
            raise ParseError("HTTP message must be bytes")
        index = data.find(b"\r\n\r\n")
        if index < 0:
            raise ParseError("Incomplete HTTP headers")
        head = data[:index]
        if len(head) > MAX_HEADER_SIZE:
            raise ParseError("Headers are too large")
        return head, data[index + 4:]

    @staticmethod
    def _parse_headers(lines: List[bytes]) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        for line in lines:
            if not line:
                continue
            if b":" not in line:
                raise ParseError("Invalid header line")
            name, value = line.split(b":", 1)
            name = name.decode("latin-1").strip()
            value = value.decode("latin-1").strip()
            if not name:
                raise ParseError("Empty header name")
            headers[name] = value
        return headers

    @staticmethod
    def _read_body(headers: Dict[str, str], body: bytes, default_all: bool = False) -> bytes:
        encoding = get_header(headers, "Transfer-Encoding")
        if encoding and "chunked" in encoding.lower():
            return Parser._decode_chunked(body)

        length_text = get_header(headers, "Content-Length")
        if length_text is None:
            return body if default_all else b""
        try:
            length = int(length_text)
        except ValueError as exc:
            raise ParseError("Invalid Content-Length") from exc
        if length < 0 or length > MAX_BODY_SIZE:
            raise ParseError("Invalid Content-Length")
        if len(body) < length:
            raise ParseError("Incomplete body")
        return body[:length]

    @staticmethod
    def _decode_chunked(data: bytes) -> bytes:
        result = b""
        position = 0
        while True:
            end = data.find(b"\r\n", position)
            if end < 0:
                raise ParseError("Incomplete chunk")
            size_text = data[position:end].split(b";")[0].strip()
            try:
                size = int(size_text, 16)
            except ValueError as exc:
                raise ParseError("Invalid chunk size") from exc
            position = end + 2
            if size == 0:
                return result
            if len(data) < position + size + 2:
                raise ParseError("Incomplete chunk data")
            result += data[position:position + size]
            if len(result) > MAX_BODY_SIZE:
                raise ParseError("Body is too large")
            position += size + 2
