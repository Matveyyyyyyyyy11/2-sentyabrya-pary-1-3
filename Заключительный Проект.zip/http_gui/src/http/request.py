"""HTTP request model."""

from dataclasses import dataclass, field
from typing import Dict, Optional


def get_header(headers: Dict[str, str], name: str) -> Optional[str]:
    """Return a header value using a case-insensitive lookup."""
    lower_name = name.lower()
    for key, value in headers.items():
        if key.lower() == lower_name:
            return value
    return None


@dataclass
class Request:
    """An HTTP request."""

    method: str
    path: str
    version: str = "HTTP/1.1"
    headers: Dict[str, str] = field(default_factory=dict)
    body: bytes = b""

    def get_header(self, name: str) -> Optional[str]:
        return get_header(self.headers, name)
