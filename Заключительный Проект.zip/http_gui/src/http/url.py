"""URL parsing for the HTTP client."""

import re
from dataclasses import dataclass

_URL_RE = re.compile(
    r"^(?P<scheme>https?)://"
    r"(?P<host>[^/:?#\s]+)"
    r"(?::(?P<port>\d+))?"
    r"(?P<path>/[^?#\s]*)?"
    r"(?:\?(?P<query>[^#\s]*))?$",
    re.IGNORECASE,
)


class ParseError(ValueError):
    """Raised when an URL or an HTTP message cannot be parsed."""


@dataclass
class Url:
    """Parsed http/https URL."""

    scheme: str
    host: str
    port: int
    path: str = "/"
    query: str = ""

    @classmethod
    def parse(cls, raw: str) -> "Url":
        if not isinstance(raw, str):
            raise ParseError("URL must be a string")
        match = _URL_RE.match(raw.strip())
        if not match:
            raise ParseError(f"Invalid URL: {raw!r}")

        scheme = match.group("scheme").lower()
        host = match.group("host")
        path = match.group("path") or "/"
        query = match.group("query") or ""

        port_text = match.group("port")
        if port_text is None:
            port = 443 if scheme == "https" else 80
        else:
            port = int(port_text)
            if not 1 <= port <= 65535:
                raise ParseError(f"Invalid port: {port}")

        return cls(scheme=scheme, host=host, port=port, path=path, query=query)

    @property
    def default_port(self) -> bool:
        return self.port == (443 if self.scheme == "https" else 80)

    @property
    def host_header(self) -> str:
        if self.default_port:
            return self.host
        return f"{self.host}:{self.port}"

    @property
    def target(self) -> str:
        if self.query:
            return f"{self.path}?{self.query}"
        return self.path
