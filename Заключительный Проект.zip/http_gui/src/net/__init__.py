"""Socket helpers, TCP client and TCP server."""
