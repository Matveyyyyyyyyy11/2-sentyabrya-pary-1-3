"""Thin context-manager wrapper around a socket."""

import socket
from typing import Optional


class Socket:
    """Owns a socket and closes it when leaving a with block."""

    def __init__(self, sock: socket.socket):
        self._sock: Optional[socket.socket] = sock

    def __enter__(self) -> "Socket":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def close(self) -> None:
        try:
            if self._sock is not None:
                self._sock.close()
        finally:
            self._sock = None

    def send_all(self, data: bytes) -> None:
        if self._sock is None:
            raise ConnectionError("Socket is closed")
        self._sock.sendall(data)

    def recv(self, size: int) -> bytes:
        if self._sock is None:
            raise ConnectionError("Socket is closed")
        return self._sock.recv(size)

    def settimeout(self, seconds: float) -> None:
        if self._sock is None:
            raise ConnectionError("Socket is closed")
        self._sock.settimeout(seconds)
