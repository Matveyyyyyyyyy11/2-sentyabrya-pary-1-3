"""TCP client with timeouts and a context manager."""

import socket
import ssl
from typing import Optional

from ..http.url import ParseError
from .socket_wrapper import Socket


class TcpClient:
    """Small TCP client used by HttpClient."""

    def __init__(self, timeout: float = 5.0):
        self._timeout = timeout
        self._socket: Optional[Socket] = None

    def __enter__(self) -> "TcpClient":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def connect(self, host: str, port: int, use_ssl: bool = False) -> None:
        raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw.settimeout(self._timeout)
        try:
            raw.connect((host, port))
            if use_ssl:
                context = ssl.create_default_context()
                raw = context.wrap_socket(raw, server_hostname=host)
                raw.settimeout(self._timeout)
        except socket.timeout as exc:
            raw.close()
            raise TimeoutError(f"Connection to {host}:{port} timed out") from exc
        except OSError as exc:
            raw.close()
            raise ConnectionError(f"Cannot connect to {host}:{port}: {exc}") from exc
        self._socket = Socket(raw)

    def send(self, data: bytes) -> None:
        self._require_socket().send_all(data)

    def recv(self, size: int = 4096) -> bytes:
        sock = self._require_socket()
        try:
            return sock.recv(size)
        except socket.timeout as exc:
            raise TimeoutError("Read timed out") from exc
        except OSError as exc:
            raise ConnectionError(f"Connection error: {exc}") from exc

    def recv_until(self, separator: bytes, max_bytes: int = 65536) -> bytes:
        data = b""
        while separator not in data:
            chunk = self.recv(4096)
            if not chunk:
                raise ConnectionError("Connection closed by server")
            data += chunk
            if len(data) > max_bytes:
                raise ParseError("Response headers are too large")
        return data

    def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None

    def _require_socket(self) -> Socket:
        if self._socket is None:
            raise ConnectionError("Not connected")
        return self._socket
