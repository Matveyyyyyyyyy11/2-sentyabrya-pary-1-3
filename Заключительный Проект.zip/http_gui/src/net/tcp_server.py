"""Threaded TCP server."""

import logging
import socket
import threading
from abc import ABC, abstractmethod
from typing import Callable, Optional

from .socket_wrapper import Socket

logger = logging.getLogger(__name__)


class Server(ABC):
    """Common interface for a network server."""

    @abstractmethod
    def start(self) -> None:
        """Start listening."""

    @abstractmethod
    def stop(self) -> None:
        """Stop listening and close active connections."""

    @property
    @abstractmethod
    def running(self) -> bool:
        """Whether the server is accepting connections."""


class TcpServer(Server):
    """Accepts connections and handles each one in its own thread."""

    def __init__(self, host: str, port: int, handler: Callable[[Socket], None],
                 backlog: int = 50):
        self._host = host
        self._port = port
        self._handler = handler
        self._backlog = backlog
        self._socket: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._connections = set()
        self._lock = threading.Lock()
        self.port = port

    @property
    def running(self) -> bool:
        return self._socket is not None and not self._stop_event.is_set()

    def start(self) -> None:
        if self.running:
            return
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((self._host, self._port))
            sock.listen(self._backlog)
            sock.settimeout(0.5)
        except OSError:
            sock.close()
            raise
        self._socket = sock
        self.port = sock.getsockname()[1]
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._accept_loop, name="tcp-accept", daemon=True)
        self._thread.start()
        logger.info("TCP server listening on %s:%s", self._host, self.port)

    def _accept_loop(self) -> None:
        while not self._stop_event.is_set():
            sock = self._socket
            if sock is None:
                break
            try:
                conn, address = sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            logger.debug("Accepted connection from %s", address)
            thread = threading.Thread(
                target=self._client_thread,
                args=(conn,),
                name=f"client-{address[1]}",
                daemon=True,
            )
            thread.start()

    def _client_thread(self, conn: socket.socket) -> None:
        with self._lock:
            self._connections.add(conn)
        try:
            with Socket(conn) as sock:
                self._handler(sock)
        except OSError:
            pass
        except Exception:  # pylint: disable=broad-exception-caught
            logger.exception("Unhandled error in client thread")
        finally:
            with self._lock:
                self._connections.discard(conn)

    def stop(self) -> None:
        if self._socket is None:
            return
        self._stop_event.set()
        sock = self._socket
        self._socket = None
        try:
            sock.close()
        except OSError:
            pass
        with self._lock:
            connections = list(self._connections)
        for conn in connections:
            try:
                conn.close()
            except OSError:
                pass
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None
        logger.info("TCP server stopped")
