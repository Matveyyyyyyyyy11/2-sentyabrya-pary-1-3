"""HTTP client and server with a tkinter GUI."""
