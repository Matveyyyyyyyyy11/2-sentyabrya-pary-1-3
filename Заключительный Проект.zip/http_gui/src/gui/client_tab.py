"""GUI tab for the HTTP client."""

import json
import queue
import threading
import tkinter as tk
from tkinter import ttk
from typing import Optional

from ..client.http_client import HttpClient, HttpError
from ..http.response import Response
from ..http.url import ParseError, Url
from .widgets import HeaderTable


class ClientTab(ttk.Frame):
    """URL, method, headers, body and the response area."""

    def __init__(self, master):
        super().__init__(master, padding=8)
        self._client = HttpClient(timeout_ms=5000)
        self._queue: queue.Queue = queue.Queue()
        self._build()
        self.after(100, self._poll_queue)

    def _build(self) -> None:
        self.columnconfigure(1, weight=1)

        ttk.Label(self, text="URL:").grid(row=0, column=0, sticky="w")
        self.url_entry = ttk.Entry(self)
        self.url_entry.insert(0, "http://localhost:8080/")
        self.url_entry.grid(row=0, column=1, sticky="ew", padx=4)

        self.method_box = ttk.Combobox(
            self, values=("GET", "POST"), state="readonly", width=8)
        self.method_box.set("GET")
        self.method_box.grid(row=0, column=2, padx=4)
        self.method_box.bind("<<ComboboxSelected>>", self._on_method_change)

        self.send_button = ttk.Button(self, text="Отправить", command=self.send_request)
        self.send_button.grid(row=0, column=3, padx=4)
        ttk.Button(self, text="Очистить", command=self.clear).grid(row=0, column=4)

        ttk.Label(self, text="Заголовки:").grid(row=1, column=0, sticky="nw", pady=(8, 0))
        self.header_table = HeaderTable(self)
        self.header_table.grid(row=1, column=1, columnspan=4, sticky="nsew", pady=(8, 0))

        ttk.Label(self, text="Тело (POST):").grid(row=2, column=0, sticky="nw", pady=(8, 0))
        self.body_text = tk.Text(self, height=6, wrap="word")
        self.body_text.grid(row=2, column=1, columnspan=4, sticky="nsew", pady=(8, 0))
        self.body_text.configure(state="disabled")

        self.progress = ttk.Progressbar(self, mode="indeterminate", length=120)
        self.progress.grid(row=3, column=0, columnspan=2, sticky="w", pady=(8, 0))
        self.status_label = ttk.Label(self, text="Готов к запросу")
        self.status_label.grid(row=3, column=2, columnspan=3, sticky="w", pady=(8, 0))

        ttk.Label(self, text="Заголовки ответа:").grid(
            row=4, column=0, sticky="nw", pady=(8, 0))
        self.response_headers = tk.Text(self, height=7, wrap="word")
        self.response_headers.grid(
            row=4, column=1, columnspan=4, sticky="nsew", pady=(8, 0))
        self.response_headers.configure(state="disabled")

        ttk.Label(self, text="Тело ответа:").grid(row=5, column=0, sticky="nw", pady=(8, 0))
        body_frame = ttk.Frame(self)
        body_frame.grid(row=5, column=1, columnspan=4, sticky="nsew", pady=(8, 0))
        body_frame.columnconfigure(0, weight=1)
        body_frame.rowconfigure(0, weight=1)
        self.response_body = tk.Text(body_frame, height=14, wrap="word")
        scrollbar = ttk.Scrollbar(body_frame, orient="vertical", command=self.response_body.yview)
        self.response_body.configure(yscrollcommand=scrollbar.set)
        self.response_body.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.response_body.configure(state="disabled")
        self.response_body.tag_configure("json", foreground="#1a5fb4")
        self.response_body.tag_configure("html", foreground="#26a269")
        self.response_body.tag_configure("error", foreground="#c01c28")

        self.rowconfigure(1, weight=1)
        self.rowconfigure(5, weight=2)

    def _on_method_change(self, _event=None) -> None:
        if self.method_box.get() == "POST":
            self.body_text.configure(state="normal")
        else:
            self.body_text.configure(state="disabled")

    def send_request(self) -> None:
        url = self.url_entry.get().strip()
        if not url:
            self._show_error("Введите URL")
            return
        try:
            Url.parse(url)
        except ParseError as exc:
            self._show_error(str(exc))
            return

        method = self.method_box.get()
        headers = self.header_table.get_headers()
        body = ""
        if method == "POST":
            body = self.body_text.get("1.0", "end-1c")

        self._set_busy(True)
        thread = threading.Thread(
            target=self._worker, args=(method, url, headers, body), daemon=True)
        thread.start()

    def _worker(self, method: str, url: str, headers: dict, body: str) -> None:
        try:
            if method == "POST":
                response = self._client.post(
                    url, body, "text/plain; charset=utf-8", headers)
            else:
                response = self._client.get(url, headers)
            self._queue.put(("response", response))
        except HttpError as exc:
            self._queue.put(("http_error", exc))
        except (ParseError, ConnectionError, TimeoutError, OSError) as exc:
            self._queue.put(("error", exc))
        except Exception as exc:  # pylint: disable=broad-exception-caught
            self._queue.put(("error", exc))

    def _poll_queue(self) -> None:
        try:
            kind, payload = self._queue.get_nowait()
        except queue.Empty:
            self.after(100, self._poll_queue)
            return

        self._set_busy(False)
        if kind == "response":
            self._show_response(payload)
        elif kind == "http_error":
            if payload.response is not None:
                self._show_response(payload.response)
            else:
                self._show_error(str(payload))
        else:
            self._show_error(str(payload))
        self.after(100, self._poll_queue)

    def _set_busy(self, busy: bool) -> None:
        if busy:
            self.send_button.configure(state="disabled")
            self.progress.start(10)
            self.status_label.configure(text="Отправка...", foreground="#1a5fb4")
        else:
            self.send_button.configure(state="normal")
            self.progress.stop()

    def _show_response(self, response: Response) -> None:
        headers_text = "\n".join(
            f"{name}: {value}" for name, value in response.headers.items())
        if not headers_text:
            headers_text = "(нет заголовков)"
        self._set_text(self.response_headers, headers_text)

        text = self._decode_body(response.body, response.get_header("Content-Type"))
        self._insert_body(text)
        color = "#26a269" if response.status < 400 else "#c01c28"
        self.status_label.configure(
            text=f"Статус: {response.status} {response.reason}", foreground=color)

    def _insert_body(self, text: str) -> None:
        tag = None
        try:
            text = json.dumps(json.loads(text), ensure_ascii=False, indent=2)
            tag = "json"
        except (ValueError, TypeError):
            lower = text.lower()
            if "<html" in lower or "<!doctype" in lower:
                tag = "html"
        self._set_text(self.response_body, text, tag)

    def _show_error(self, message: str) -> None:
        self._set_busy(False)
        self.status_label.configure(text=f"Ошибка: {message}", foreground="#c01c28")
        self._set_text(self.response_headers, "")
        self._set_text(self.response_body, message, "error")

    @staticmethod
    def _decode_body(body: bytes, content_type: Optional[str]) -> str:
        charset = "utf-8"
        if content_type and "charset=" in content_type.lower():
            charset = content_type.lower().split("charset=")[-1].split(";")[0].strip()
        try:
            return body.decode(charset, errors="replace")
        except LookupError:
            return body.decode("utf-8", errors="replace")

    @staticmethod
    def _set_text(widget: tk.Text, text: str, tag: Optional[str] = None) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", tk.END)
        if tag:
            widget.insert("1.0", text, tag)
        else:
            widget.insert("1.0", text)
        widget.configure(state="disabled")

    def clear(self) -> None:
        self.header_table.clear()
        self.body_text.configure(state="normal")
        self.body_text.delete("1.0", tk.END)
        if self.method_box.get() != "POST":
            self.body_text.configure(state="disabled")
        self._set_text(self.response_headers, "")
        self._set_text(self.response_body, "")
        self.status_label.configure(text="Готов к запросу", foreground="black")
