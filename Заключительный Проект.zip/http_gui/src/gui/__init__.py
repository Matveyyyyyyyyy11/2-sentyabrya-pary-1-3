"""tkinter user interface."""
