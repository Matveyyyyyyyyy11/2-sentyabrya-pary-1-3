"""Main application window."""

import tkinter as tk
from tkinter import ttk

from .client_tab import ClientTab
from .server_tab import ServerTab


class App(tk.Tk):
    """Main window with the client and server tabs."""

    def __init__(self):
        super().__init__()
        self.title("HTTP-клиент и сервер")
        self.geometry("1000x760")
        self.minsize(800, 600)

        notebook = ttk.Notebook(self)
        self.client_tab = ClientTab(notebook)
        self.server_tab = ServerTab(notebook)
        notebook.add(self.client_tab, text="Клиент")
        notebook.add(self.server_tab, text="Сервер")
        notebook.pack(fill="both", expand=True, padx=6, pady=6)

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _on_close(self) -> None:
        self.server_tab.shutdown()
        self.destroy()
