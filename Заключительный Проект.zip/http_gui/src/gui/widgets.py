"""Reusable tkinter widgets."""

import tkinter as tk
from tkinter import messagebox, ttk


class HeaderTable(ttk.Frame):
    """Editable table of HTTP headers."""

    def __init__(self, master):
        super().__init__(master)
        self.tree = ttk.Treeview(self, columns=("name", "value"), show="headings", height=5)
        self.tree.heading("name", text="Заголовок")
        self.tree.heading("value", text="Значение")
        self.tree.column("name", width=180, stretch=False)
        self.tree.column("value", width=420)
        self.tree.grid(row=0, column=0, columnspan=4, sticky="nsew")

        self.name_entry = ttk.Entry(self)
        self.value_entry = ttk.Entry(self)
        self.name_entry.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.value_entry.grid(row=1, column=1, sticky="ew", pady=(4, 0))
        ttk.Button(self, text="Добавить", command=self.add_from_entries).grid(
            row=1, column=2, padx=4, pady=(4, 0))
        ttk.Button(self, text="Удалить", command=self.remove_selected).grid(
            row=1, column=3, pady=(4, 0))
        self.name_entry.bind("<Return>", lambda _event: self.add_from_entries())
        self.value_entry.bind("<Return>", lambda _event: self.add_from_entries())

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(0, weight=1)

    def add_from_entries(self) -> None:
        name = self.name_entry.get().strip()
        value = self.value_entry.get().strip()
        if not name:
            messagebox.showerror("Ошибка", "Имя заголовка не может быть пустым", parent=self)
            return
        if ":" in name or " " in name:
            messagebox.showerror(
                "Ошибка", "Имя заголовка не должно содержать пробелы и ':'", parent=self)
            return
        self.add(name, value)
        self.name_entry.delete(0, tk.END)
        self.value_entry.delete(0, tk.END)

    def add(self, name: str, value: str) -> None:
        self.tree.insert("", tk.END, values=(name, value))

    def remove_selected(self) -> None:
        for item in self.tree.selection():
            self.tree.delete(item)

    def get_headers(self) -> dict:
        headers = {}
        for item in self.tree.get_children():
            name, value = self.tree.item(item, "values")
            headers[name] = value
        return headers

    def clear(self) -> None:
        for item in self.tree.get_children():
            self.tree.delete(item)


class LogTable(ttk.Frame):
    """Server request log."""

    COLUMNS = ("time", "method", "path", "status", "ms")
    TITLES = {
        "time": "Время",
        "method": "Метод",
        "path": "Путь",
        "status": "Статус",
        "ms": "мс",
    }
    WIDTHS = {"time": 90, "method": 80, "path": 320, "status": 70, "ms": 70}

    def __init__(self, master):
        super().__init__(master)
        self.tree = ttk.Treeview(self, columns=self.COLUMNS, show="headings")
        for column in self.COLUMNS:
            self.tree.heading(column, text=self.TITLES[column])
            self.tree.column(column, width=self.WIDTHS[column], stretch=column == "path")
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

    def add(self, time_text: str, method: str, path: str, status: int, ms: float) -> None:
        self.tree.insert("", 0, values=(time_text, method, path, status, f"{ms:.1f}"))

    def clear(self) -> None:
        for item in self.tree.get_children():
            self.tree.delete(item)
