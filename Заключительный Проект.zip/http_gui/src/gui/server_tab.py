"""GUI tab for the HTTP server."""

import queue
import webbrowser
from tkinter import messagebox, ttk

from ..server.handlers import create_router
from ..server.http_server import HttpServer
from .widgets import LogTable


class ServerTab(ttk.Frame):
    """Port, start/stop buttons and the request log."""

    def __init__(self, master):
        super().__init__(master, padding=8)
        self._server = None
        self._log_queue: queue.Queue = queue.Queue()
        self._build()
        self.after(100, self._poll_queue)

    def _build(self) -> None:
        self.columnconfigure(1, weight=1)

        ttk.Label(self, text="Порт:").grid(row=0, column=0, sticky="w")
        self.port_entry = ttk.Entry(self, width=10)
        self.port_entry.insert(0, "8080")
        self.port_entry.grid(row=0, column=1, sticky="w", padx=4)

        self.start_button = ttk.Button(self, text="Запустить", command=self.start_server)
        self.start_button.grid(row=0, column=2, padx=4)
        self.stop_button = ttk.Button(
            self, text="Остановить", command=self.stop_server, state="disabled")
        self.stop_button.grid(row=0, column=3, padx=4)
        ttk.Button(self, text="Открыть в браузере", command=self.open_browser).grid(
            row=0, column=4, padx=4)
        ttk.Button(self, text="Очистить лог", command=self.clear_log).grid(
            row=0, column=5, padx=4)

        self.state_label = ttk.Label(self, text="● Остановлен", foreground="#c01c28")
        self.state_label.grid(row=1, column=0, columnspan=3, sticky="w", pady=(8, 0))

        self.log_table = LogTable(self)
        self.log_table.grid(row=2, column=0, columnspan=6, sticky="nsew", pady=(8, 0))
        self.rowconfigure(2, weight=1)

    def start_server(self) -> None:
        port_text = self.port_entry.get().strip()
        if not port_text.isdigit() or not 1 <= int(port_text) <= 65535:
            messagebox.showerror(
                "Ошибка", "Порт должен быть числом от 1 до 65535", parent=self)
            return

        server = HttpServer(
            port=int(port_text), router=create_router(), on_log=self._enqueue_log)
        try:
            server.start()
        except OSError as exc:
            messagebox.showerror(
                "Ошибка", f"Не удалось запустить сервер: {exc}", parent=self)
            return

        self._server = server
        self.port_entry.configure(state="disabled")
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.state_label.configure(
            text=f"● Работает на порту {server.port}", foreground="#26a269")

    def stop_server(self) -> None:
        if self._server is not None:
            self._server.stop()
            self._server = None
        self.port_entry.configure(state="normal")
        self.start_button.configure(state="normal")
        self.stop_button.configure(state="disabled")
        self.state_label.configure(text="● Остановлен", foreground="#c01c28")

    def open_browser(self) -> None:
        if self._server is not None:
            port = self._server.port
        else:
            text = self.port_entry.get().strip()
            port = int(text) if text.isdigit() else 8080
        webbrowser.open(f"http://localhost:{port}/")

    def clear_log(self) -> None:
        self.log_table.clear()

    def _enqueue_log(self, time_text: str, method: str, path: str,
                     status: int, ms: float) -> None:
        self._log_queue.put((time_text, method, path, status, ms))

    def _poll_queue(self) -> None:
        for _ in range(200):
            try:
                entry = self._log_queue.get_nowait()
            except queue.Empty:
                break
            self.log_table.add(*entry)
        self.after(100, self._poll_queue)

    def shutdown(self) -> None:
        if self._server is not None:
            self._server.stop()
            self._server = None
