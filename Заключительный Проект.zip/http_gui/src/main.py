"""Application entry point."""

import logging

from .gui.app import App


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[
            logging.FileHandler("http_gui.log", encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def main() -> None:
    setup_logging()
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
