"""Manual load check against a server started from the GUI (screenshot S12).

Usage:
    python load_test.py
    python load_test.py --url http://localhost:8080/time --requests 100
"""

import argparse
import time
from concurrent.futures import ThreadPoolExecutor

from src.client.http_client import HttpClient


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Send parallel GET requests")
    parser.add_argument("--url", default="http://localhost:8080/time")
    parser.add_argument("--requests", type=int, default=100)
    parser.add_argument("--workers", type=int, default=100)
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    def worker(_index: int) -> int:
        client = HttpClient(timeout_ms=10000)
        return client.get(args.url).status

    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        statuses = list(pool.map(worker, range(args.requests)))
    elapsed = time.perf_counter() - started

    ok = statuses.count(200)
    print(f"{ok}/{len(statuses)} requests returned 200 in {elapsed:.2f}s")
    if ok != len(statuses):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
