# HTTP-клиент и сервер с графическим интерфейсом

Учебный проект: HTTP/1.1 клиент и многопоточный HTTP-сервер на чистых сокетах
(`socket` + `threading`) с графическим интерфейсом на `tkinter`.
Сторонние HTTP-библиотеки не используются.

## Как запустить (Windows)

Открыть PowerShell и перейти в папку проекта:

```powershell
cd C:\Users\Пользователь\source\repos\http_gui
```

Создать виртуальное окружение (достаточно один раз):

```powershell
python -m venv .venv
```

Установить зависимости (нужны для тестов и линтеров):

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Запустить приложение:

```powershell
.\.venv\Scripts\python.exe -m src.main
```

Если виртуальное окружение не используется, достаточно:

```powershell
python -m src.main
```

Откроется окно с двумя вкладками: «Клиент» и «Сервер».

## Как пользоваться

### Вкладка «Клиент»

1. Ввести URL, например `http://example.com/` или `http://localhost:8080/time`.
2. Выбрать метод `GET` или `POST`.
3. При необходимости добавить заголовки: ввести имя и значение, нажать
   «Добавить». Удалить заголовок — выделить строку и нажать «Удалить».
4. Для `POST` ввести тело запроса в поле «Тело (POST)».
5. Нажать «Отправить». Во время запроса показывается «Отправка...»,
   окно не замерзает.
6. Внизу появится статус, заголовки и тело ответа. JSON и HTML
   подсвечиваются, ошибки показываются красным.
7. «Очистить» сбрасывает поля и область ответа.

Примеры для клиента:

| URL | Метод | Тело | Результат |
| --- | --- | --- | --- |
| `http://example.com/` | GET | — | 200, HTML-страница |
| `http://localhost:8080/` | GET | — | 200, страница «Hello» |
| `http://localhost:8080/time` | GET | — | 200, JSON со временем |
| `http://localhost:8080/headers` | GET | — | 200, JSON с заголовками |
| `http://localhost:8080/echo` | POST | `hello` | 200, тело `hello` |
| `http://localhost:8080/status/418` | GET | — | 418 |
| `http://localhost:8080/nonexistent` | GET | — | 404 |

Для запросов на `localhost:8080` сервер должен быть запущен на вкладке
«Сервер». Если он не запущен, в области ответа появится ошибка
`ConnectionError` / «Connection refused».

### Вкладка «Сервер»

1. Указать порт (по умолчанию `8080`).
2. Нажать «Запустить» — индикатор станет зелёным.
3. Нажать «Открыть в браузере» — откроется `http://localhost:8080/`.
4. В таблице лога появятся время, метод, путь, статус и время обработки
   в миллисекундах.
5. «Остановить» останавливает сервер и освобождает порт.
6. «Очистить лог» очищает таблицу.

Проверка из терминала, пока сервер запущен:

```powershell
curl -v http://localhost:8080/
curl -v -X POST -d "hello" http://localhost:8080/echo
curl -v http://localhost:8080/status/418
curl -v http://localhost:8080/nonexistent
```

Запросы клиента и работа сервера выполняются в фоновых потоках, GUI
обновляется только из главного потока через `queue.Queue` и `root.after`.

## Если что-то не работает

* **`python` не найден** — использовать `.\.venv\Scripts\python.exe` или
  команду `py` вместо `python`.
* **PowerShell не даёт активировать venv** — активация не обязательна,
  запускайте через `.\.venv\Scripts\python.exe`. Либо разрешить активацию
  на текущую сессию:
  `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`.
* **`OSError: [WinError 10048]` при запуске сервера** — порт уже занят.
  Указать другой порт, например `8081`.
* **`Connection refused` в клиенте** — сервер не запущен или указан
  неверный порт.
* **`TimeoutError`** — сервер не отвечает. Таймаут клиента задан в
  `src/gui/client_tab.py` (`HttpClient(timeout_ms=5000)`).
* **Нет окна при запуске** — проверить, что установлен Python с tkinter
  (на Windows он входит в стандартную установку).

## Маршруты сервера

| Маршрут | Метод | Ответ |
| --- | --- | --- |
| `/` | GET | HTML-страница «Hello» |
| `/echo` | POST | эхо тела, `Content-Type` сохраняется |
| `/time` | GET | текущее время в JSON |
| `/headers` | GET | заголовки запроса в JSON |
| `/status/{code}` | GET | ответ с указанным статус-кодом |
| любой другой | любой | 404 Not Found |

Дополнительно поддерживаются `Connection: keep-alive`, `Content-Length`,
`Transfer-Encoding: chunked` в ответах, HTTPS на клиенте (через `ssl`),
редиректы (если включить `follow_redirects`).

## Структура

```text
http_gui/
├── src/
│   ├── http/          # Url, Request, Response, Parser, Serializer
│   ├── net/           # Socket, TcpClient, TcpServer
│   ├── client/        # HttpClient
│   ├── server/        # HttpServer, Router, handlers
│   ├── gui/           # app, client_tab, server_tab, widgets
│   └── main.py        # точка входа
├── tests/
│   ├── test_url.py
│   ├── test_parser.py
│   ├── test_serializer.py
│   └── test_integration.py
├── requirements.txt
├── pytest.ini
├── setup.cfg
├── pylintrc
├── Makefile
└── README.md
```

Ключевые классы: `Url`, `Request`, `Response`, `Parser`, `Serializer`,
`Socket`, `TcpClient`, `TcpServer`, `HttpClient`, `HttpServer`, `Router`.
Два интерфейса на `ABC`: `Client` (клиент) и `Server` (сервер).

## Тесты и линтеры

```bash
pytest tests/ -v          # unit + интеграционные
pytest tests/test_integration.py -v
flake8 src/ tests/
pylint src/
```

pylint использует pylintrc: отключены только стилевые проверки
(docstring, метрики классов), ошибок и предупреждений нет.

Интеграционные тесты поднимают настоящий сервер на свободном порту и
проверяют GET, POST, 404/418, таймаут, мусорный запрос, keep-alive,
последовательные и параллельные запросы.

## Ручная проверка

```bash
python -m src.main
curl -v http://localhost:8080/
curl -v -X POST -d "hello" http://localhost:8080/echo
curl -v http://localhost:8080/status/418
curl -v http://localhost:8080/nonexistent
```

## Примечания

* `HttpClient` по умолчанию бросает `HttpError` при статусе 4xx/5xx;
  объект ответа доступен в `HttpError.response`, поэтому GUI всё равно
  показывает статус, заголовки и тело.
* Ошибки `ConnectionError`, `TimeoutError`, `ParseError` показываются
  в области ответа, а не в консоли.
* Логи пишутся в файл `http_gui.log` (модуль `logging`) и в таблицу
  на вкладке «Сервер».
* Сервер обрабатывает каждое соединение в отдельном потоке, поэтому
  параллельные запросы не блокируют друг друга.
